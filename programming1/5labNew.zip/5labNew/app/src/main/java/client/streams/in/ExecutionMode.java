package client.streams.in;

/**
 * ExecutionType Enum
 * Show how we open OutStream 
 */

public enum ExecutionMode {
    CLI,
    EXECUTESCRIPT
}
