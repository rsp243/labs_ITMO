package server.data.enums;

public enum Climate {
    RAIN_FOREST,
    HUMIDSUBTROPICAL,
    HUMIDCONTINENTAL,
    SUBARCTIC,
    TUNDRA;
}
