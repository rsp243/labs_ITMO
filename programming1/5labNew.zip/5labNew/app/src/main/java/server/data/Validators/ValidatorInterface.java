package server.data.Validators;

public interface ValidatorInterface<E> {
    public boolean validate(E variable);
}
